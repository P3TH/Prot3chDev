==Millénaire installation==

Since Millénaire 3.0, the installation procedure has changed. To install it manually, you now need to:
- Install Forge from http://minecraftforge.net/forum/index.php/board,3.0.html
- Move the millenaire zip and the millenaire and millenaire-custom folders inside /mods (create the folder if needed)

You can also install Millénaire using the installer provided on millenaire.org