package gregtechmod.api;

import gregtechmod.GT_Mod;
import gregtechmod.common.GT_ModHandler;
import ic2.api.Direction;
import ic2.api.ElectricItem;
import ic2.api.IElectricItem;
import ic2.api.IEnergyStorage;
import ic2.api.IWrenchable;
import ic2.api.energy.EnergyNet;
import ic2.api.energy.tile.IEnergySink;
import ic2.api.energy.tile.IEnergySource;
import ic2.api.network.INetworkDataProvider;
import ic2.api.network.INetworkUpdateListener;
import ic2.api.network.NetworkHelper;

import java.util.ArrayList;
import java.util.List;

import net.minecraft.block.Block;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagList;
import net.minecraft.tileentity.TileEntity;
import net.minecraftforge.common.ForgeDirection;
import net.minecraftforge.common.ISidedInventory;
import net.minecraftforge.liquids.ILiquidTank;
import net.minecraftforge.liquids.ITankContainer;
import net.minecraftforge.liquids.LiquidStack;

/**
 * Do never include this Class in a Copy of my API. It will cause incompatiblities!
 * 
 * This is only here to not give you Compile-Errors. The GT_ModHander can easyly be commented out for your compiling.
 * Note that this file will contain all the needed Code of the Interfaces for wrenching, energynet and similar things.
 */
public class BaseMetaTileEntity extends TileEntity implements ITankContainer, IEnergyStorage, IWrenchable, ISidedInventory, IEnergySink, IEnergySource, IGregTechDeviceInformation, IMachineBlockUpdateable, INetworkDataProvider, INetworkUpdateListener {
	public static final short MAXIMUM_METATILE_IDS = 1024;
	public static boolean sAnimationsAllowed = true;
	
	public static MetaTileEntity[] mMetaTileList = new MetaTileEntity[MAXIMUM_METATILE_IDS];
	
	public MetaTileEntity mMetaTileEntity;
	public int mFacing = -1, oFacing = -1, oOutput = 0, mStoredEnergy = 0, mID = 0, mDisplayErrorCode = 0, oX = 0, oY = 0, oZ = 0;
	public long mTickTimer = 0;
	public boolean mActive = false, oActive = false, mIsAddedToEnet = false, mNeedsUpdate = true, mRedstone = false, oRedstone = false, mReleaseEnergy = false;
	public String mOwnerName = "";
	
	@Override
    public void writeToNBT(NBTTagCompound aNBT) {
    	super.writeToNBT(aNBT);
        aNBT.setInteger	("mID"			, mID);
        aNBT.setInteger	("mStoredEnergy", mStoredEnergy);
        aNBT.setShort	("mFacing"		, (short)mFacing);
        aNBT.setString	("mOwnerName"	, mOwnerName);
    	aNBT.setBoolean	("mActive"		, mActive);
    	aNBT.setBoolean	("mRedstone"	, mRedstone);
    	
    	if (hasValidMetaTileEntity()) {
    		try {
    			mMetaTileEntity.saveNBTData(aNBT);
    		} catch(Throwable e) {
    			System.err.println("Encountered CRITICAL ERROR while saving MetaTileEntity, the Chunk whould've been corrupted by now, but I prevented that. Please report immidietly to GregTech Intergalactical!!!");
    			e.printStackTrace();
    		}
	        NBTTagList tItemList = new NBTTagList();
	        for (int i = 0; i < mMetaTileEntity.mInventory.length; i++) {
	            ItemStack tStack = mMetaTileEntity.mInventory[i];
	            if (tStack != null) {
	                NBTTagCompound tTag = new NBTTagCompound();
	                tTag.setInteger("IntSlot", i);
	                tStack.writeToNBT(tTag);
	                tItemList.appendTag(tTag);
	            }
	        }
	        aNBT.setTag("Inventory", tItemList);
    	}
    }

	@Override
	public void readFromNBT(NBTTagCompound aNBT) {
		super.readFromNBT(aNBT);
        mID				= aNBT.getInteger	("mID");
        mStoredEnergy	= aNBT.getInteger	("mStoredEnergy");
        mFacing			= aNBT.getShort		("mFacing");
        mOwnerName		= aNBT.getString	("mOwnerName");
    	mActive			= aNBT.getBoolean	("mActive");
    	mRedstone		= aNBT.getBoolean	("mRedstone");
    	
    	if (mID != 0 && createNewMetatileEntity(mID)) {
    		try {
    			mMetaTileEntity.loadNBTData(aNBT);
        	} catch(Throwable e) {
        		System.err.println("Encountered Exception while loading MetaTileEntity, the Server should've crashed now, but I prevented that. Please report immidietly to GregTech Intergalactical!!!");
        		e.printStackTrace();
        	}
	        NBTTagList tItemList = aNBT.getTagList("Inventory");
	        for (int i = 0; i < tItemList.tagCount(); i++) {
	            NBTTagCompound tTag = (NBTTagCompound)tItemList.tagAt(i);
	            int tSlot = tTag.getInteger("IntSlot");
	            if (tSlot >= 0 && tSlot < mMetaTileEntity.mInventory.length) {
	            	mMetaTileEntity.mInventory[tSlot] = ItemStack.loadItemStackFromNBT(tTag);
	            }
	        }
		}
    }
	
	public boolean createNewMetatileEntity(int aID) {
		if (aID < 16 || aID >= MAXIMUM_METATILE_IDS || mMetaTileList[aID] == null) {
			System.err.println("MetaID " + aID + " not loadable => locking TileEntity!");
		} else {
			if (aID != 0) {
				if (hasValidMetaTileEntity()) {
					mMetaTileEntity.inValidate();
					mMetaTileEntity.mBaseMetaTileEntity = null;
				}
				mMetaTileEntity = mMetaTileList[aID].newMetaEntity(this);
				mMetaTileEntity.mBaseMetaTileEntity = this;
	    		mTickTimer = 0;
				mID = aID;
				return true;
			}
		}
		return false;
	}
	
	@Override
    public void updateEntity() {
    	if (isInvalid()) return;
    	
    	if (!hasValidMetaTileEntity()) {
    		if (worldObj.isRemote) worldObj.addBlockEvent(xCoord, yCoord, zCoord, worldObj.getBlockId(xCoord, yCoord, zCoord), 3, 0);
	    	if (mMetaTileEntity == null) {
	    		return;
	    	} else {
	    		mMetaTileEntity.mBaseMetaTileEntity = this;
	    	}
    	}
    	
    	try {
    	
    	mTickTimer++;

	    if (mTickTimer==20) {
    		if (mFacing == -1) mFacing = 0;
	    	if (!worldObj.isRemote) {
	    		worldObj.addBlockEvent(xCoord, yCoord, zCoord, worldObj.getBlockId(xCoord, yCoord, zCoord), 3, mID);
	    	}
    		mMetaTileEntity.onFirstTick();
    		NetworkHelper.updateTileEntityField(this, "mOwnerName");
	    }
    	
    	if (mTickTimer>20 && hasValidMetaTileEntity()) {
    		mMetaTileEntity.onPreTick();
        	
    	    if (worldObj.isRemote) {
    	    	if ((mNeedsUpdate || mMetaTileEntity.hasAnimation()) && (sAnimationsAllowed || mTickTimer<250)) {
    			    worldObj.markBlockForRenderUpdate(xCoord, yCoord, zCoord);
    			    mNeedsUpdate = false;
    	    	}
    	    } else {
    	    	if (mTickTimer == 100) {
    	    		worldObj.notifyBlocksOfNeighborChange(xCoord, yCoord, zCoord, worldObj.getBlockId(xCoord, yCoord, zCoord));
    	    	}
    		    if (mNeedsUpdate || mTickTimer%100==50) {
	    	    	worldObj.addBlockEvent(xCoord, yCoord, zCoord, worldObj.getBlockId(xCoord, yCoord, zCoord), 0, mFacing);
	    		    worldObj.addBlockEvent(xCoord, yCoord, zCoord, worldObj.getBlockId(xCoord, yCoord, zCoord), 1, mActive?1:0);
	    		    worldObj.addBlockEvent(xCoord, yCoord, zCoord, worldObj.getBlockId(xCoord, yCoord, zCoord), 2, mRedstone?1:0);
    	    		worldObj.addBlockEvent(xCoord, yCoord, zCoord, worldObj.getBlockId(xCoord, yCoord, zCoord), 3, mID);
    			    mNeedsUpdate = false;
    	    	}
    	    	if (mActive != oActive) {
    	    		oActive = mActive;
    			    mNeedsUpdate = true;
    	    	}

    	    	if (mRedstone != oRedstone) {
    		    	worldObj.notifyBlocksOfNeighborChange(xCoord, yCoord, zCoord, worldObj.getBlockId(xCoord, yCoord, zCoord));
    	    		oRedstone = mRedstone;
    			    mNeedsUpdate = true;
    	    	}
    	    	
    	    	if (mTickTimer > 30 && (mMetaTileEntity.isEnetOutput()||mMetaTileEntity.isEnetInput()) && !mIsAddedToEnet) {
    	    		mIsAddedToEnet = GT_ModHandler.addTileToEnet(this);
    	    	}
    	    	
    	    	if (xCoord != oX || yCoord != oY || zCoord != oZ) {
    	    		oX = xCoord;
    	    		oY = yCoord;
    	    		oZ = zCoord;
    		    	if (mIsAddedToEnet) GT_ModHandler.removeTileFromEnet(this);
    		    	mIsAddedToEnet = false;
    			    mNeedsUpdate = true;
    	    	}
    	    	
    		    if (mFacing != oFacing) {
    		    	oFacing = mFacing;
    		    	if (mIsAddedToEnet) GT_ModHandler.removeTileFromEnet(this);
    		    	mIsAddedToEnet = false;
    		    	mNeedsUpdate = true;
    		    }
    	    	
    		    if (getOutput() != oOutput) {
    		    	oOutput = getOutput();
    		    	if (mIsAddedToEnet) GT_ModHandler.removeTileFromEnet(this);
    		    	mIsAddedToEnet = false;
    		    }

    		    if (mIsAddedToEnet && GT_Mod.instance.mMachineFireExplosions && worldObj.rand.nextInt(1000) == 0) {
    		    	switch (worldObj.rand.nextInt(6)) {
    		    	case 0:
    		    		if (worldObj.getBlockId(xCoord+1, yCoord, zCoord) == Block.fire.blockID) doEnergyExplosion();
    		    		break;
    		    	case 1:
    		    		if (worldObj.getBlockId(xCoord-1, yCoord, zCoord) == Block.fire.blockID) doEnergyExplosion();
    		    		break;
    		    	case 2:
    		    		if (worldObj.getBlockId(xCoord, yCoord+1, zCoord) == Block.fire.blockID) doEnergyExplosion();
    		    		break;
    		    	case 3:
    		    		if (worldObj.getBlockId(xCoord, yCoord-1, zCoord) == Block.fire.blockID) doEnergyExplosion();
    		    		break;
    		    	case 4:
    		    		if (worldObj.getBlockId(xCoord, yCoord, zCoord+1) == Block.fire.blockID) doEnergyExplosion();
    		    		break;
    		    	case 5:
    		    		if (worldObj.getBlockId(xCoord, yCoord, zCoord-1) == Block.fire.blockID) doEnergyExplosion();
    		    		break;
    		    	}
    		    }
    		    
    	        if (mIsAddedToEnet && mMetaTileEntity.isEnetOutput() && mMetaTileEntity.getEnergyVar() >= Math.max(mMetaTileEntity.maxEUOutput(), mMetaTileEntity.getMinimumStoredEU()) && mMetaTileEntity.maxEUOutput() > 0) {
    	            try {
    	            	EnergyNet tEnergyNet = EnergyNet.getForWorld(worldObj);
    	            	if (tEnergyNet != null)
    	            		setStoredEnergy(mMetaTileEntity.getEnergyVar() + tEnergyNet.emitEnergyFrom(this, mMetaTileEntity.maxEUOutput()) - mMetaTileEntity.maxEUOutput());
    	            } catch(Exception e) {
    	            	
    	            }
    	        }
    	        
    	        for (int j = 0; j < mMetaTileEntity.getInputTier(); j++) {
    		        for (int i = mMetaTileEntity.dechargerSlotStartIndex(); i < mMetaTileEntity.dechargerSlotCount()+mMetaTileEntity.dechargerSlotStartIndex(); i++) {
    			        if (mMetaTileEntity.mInventory[i] != null && demandsEnergy()>0 && mMetaTileEntity.mInventory[i].getItem() instanceof IElectricItem && ((IElectricItem)mMetaTileEntity.mInventory[i].getItem()).canProvideEnergy())
    			        	increaseStoredEnergy(ElectricItem.discharge(mMetaTileEntity.mInventory[i], mMetaTileEntity.maxEUStore() - mMetaTileEntity.getEnergyVar(), mMetaTileEntity.getInputTier(), false, false), true);
    		        }
    	        }

        	    for (int j = 0; j < mMetaTileEntity.getOutputTier(); j++) {
    		        for (int i = mMetaTileEntity.rechargerSlotStartIndex(); i < mMetaTileEntity.rechargerSlotCount()+mMetaTileEntity.rechargerSlotStartIndex(); i++) {
    			        if (mMetaTileEntity.getEnergyVar() > 0 && mMetaTileEntity.mInventory[i] != null && mMetaTileEntity.mInventory[i].getItem() instanceof IElectricItem)
    			        	decreaseStoredEnergy(ElectricItem.charge(mMetaTileEntity.mInventory[i], mMetaTileEntity.getEnergyVar(), mMetaTileEntity.getOutputTier(), false, false), true);
    		        }
    	        }
    	    }

    	    mMetaTileEntity.onPostTick();
        	
        	onInventoryChanged();
    	}
    	
    	} catch(Throwable e) {
    		System.err.println("Encountered Exception while ticking TileEntity, the Game should've crashed now, but I prevented that. Please report immidietly to GregTech Intergalactical!!!");
    		e.printStackTrace();
    	}
    }
    
    @Override
    public void receiveClientEvent(int aEventID, int aValue) {
		super.receiveClientEvent(aEventID, aValue);
		
		if (hasValidMetaTileEntity()) {
			try {
				mMetaTileEntity.receiveClientEvent(aEventID, aValue);
			} catch(Throwable e) {
				System.err.println("Encountered Exception while receiving Data from the Server, the Client should've been crashed by now, but I prevented that. Please report immidietly to GregTech Intergalactical!!!");
				e.printStackTrace();
			}
		}
		
		if (worldObj.isRemote) {
			switch(aEventID) {
			case 0:
				mFacing = (short)aValue;
				mNeedsUpdate = true;
				break;
			case 1:
		    	mActive = (aValue!=0);
				mNeedsUpdate = true;
		    	break;
			case 2:
		    	mRedstone = (aValue!=0);
				mNeedsUpdate = true;
		    	break;
			case 3:
				if (mID == 0 && aValue != 0) {
			    	mID = aValue;
			    	createNewMetatileEntity(mID);
					mNeedsUpdate = true;
				}
		    	break;
			case 4:
				if (hasValidMetaTileEntity()) mMetaTileEntity.doSound(aValue, xCoord+0.5, yCoord+0.5, zCoord+0.5);
		    	break;
			case 5:
				if (hasValidMetaTileEntity()) mMetaTileEntity.startSoundLoop(aValue, xCoord+0.5, yCoord+0.5, zCoord+0.5);
		    	break;
			case 6:
				if (hasValidMetaTileEntity()) mMetaTileEntity.stopSoundLoop(aValue, xCoord+0.5, yCoord+0.5, zCoord+0.5);
		    	break;
			}
		} else {
			if (aEventID == 3 && aValue == 0) mNeedsUpdate = true;
		}
	}
    
	public ArrayList<String> getDebugInfo(EntityPlayer aPlayer, int aLogLevel) {
		ArrayList<String> tList = new ArrayList<String>();
		if (aLogLevel > 2) {
			
		}
		if (aLogLevel > 1) {
			tList.add("Is" + (mMetaTileEntity.isAccessAllowed(aPlayer)?" ":" not ") + "accessible for you");
		}
		if (aLogLevel > 0) {
			tList.add("Machine is " + (mActive?"active":"inactive"));
		}
		return mMetaTileEntity.getSpecialDebugInfo(aPlayer, aLogLevel, tList);
	}
	
    /**
     * Here at this Line begins "Code-I-will-most-likely-never-touch-again-but-where-I-have-to-fix-most-bugs"
     */
	@Override public String getMainInfo() {if (hasValidMetaTileEntity()) return mMetaTileEntity.getMainInfo(); return "";}
	@Override public String getSecondaryInfo() {if (hasValidMetaTileEntity()) return mMetaTileEntity.getSecondaryInfo(); return "";}
	@Override public String getTertiaryInfo() {if (hasValidMetaTileEntity()) return mMetaTileEntity.getTertiaryInfo(); return "";}
	@Override public boolean isGivingInformation() {if (hasValidMetaTileEntity()) return mMetaTileEntity.isGivingInformation(); return false;}
	@Override public boolean wrenchCanSetFacing(EntityPlayer aPlayer, int aSide) {if (hasValidMetaTileEntity()) return mFacing != aSide && mMetaTileEntity.isFacingValid(aSide); return false;}
	@Override public short getFacing() {return (short)mFacing;}
	@Override public void setFacing(short aFacing) {if (hasValidMetaTileEntity() && mMetaTileEntity.isFacingValid(aFacing)) mFacing = aFacing; mNeedsUpdate = true; onMachineBlockUpdate();}
	@Override public boolean wrenchCanRemove(EntityPlayer aPlayer) {if (hasValidMetaTileEntity()) return playerOwnsThis(aPlayer); return true;}
	@Override public float getWrenchDropRate() {if (hasValidMetaTileEntity() && mMetaTileEntity.isSimpleMachine()) return 1.0F; return 0.8F;}
	@Override public int getSizeInventory() {if (hasValidMetaTileEntity()) return mMetaTileEntity.getInvSize(); else return 0;}
	@Override public ItemStack getStackInSlot(int aIndex) {if (hasValidMetaTileEntity()) return mMetaTileEntity.mInventory[aIndex]; return null;}
	@Override public void setInventorySlotContents(int aIndex, ItemStack aStack) {if (hasValidMetaTileEntity()) mMetaTileEntity.mInventory[aIndex] = aStack;}
	@Override public String getInvName() {if (BaseMetaTileEntity.mMetaTileList[mID] != null) return BaseMetaTileEntity.mMetaTileList[mID].mName; return "";}
	@Override public int getInventoryStackLimit() {return 64;}
	@Override public void openChest()  {if (hasValidMetaTileEntity()) mMetaTileEntity.onOpenGUI();}
	@Override public void closeChest() {if (hasValidMetaTileEntity()) mMetaTileEntity.onCloseGUI();}
	@Override public int getStartInventorySide(ForgeDirection aSide) {if (hasValidMetaTileEntity()) return mMetaTileEntity.getInvSideIndex(aSide, mFacing); return 0;}
	@Override public int getSizeInventorySide(ForgeDirection aSide) {if (hasValidMetaTileEntity()) return mMetaTileEntity.getInvSideLength(aSide, mFacing); return 0;}
	@Override public boolean isAddedToEnergyNet() {return mIsAddedToEnet;}
    @Override public boolean isUseableByPlayer(EntityPlayer aPlayer) {return hasValidMetaTileEntity() && playerOwnsThis(aPlayer) && mTickTimer>40 && worldObj.getBlockTileEntity(xCoord, yCoord, zCoord) == this && aPlayer.getDistanceSq(xCoord + 0.5, yCoord + 0.5, zCoord + 0.5) < 64 && mMetaTileEntity.isAccessAllowed(aPlayer);}
    @Override public int getStored() {if (hasValidMetaTileEntity()) return Math.min(mMetaTileEntity.getEnergyVar(), getCapacity()); return 0;}
    @Override public void validate() {super.validate(); mNeedsUpdate = true; mTickTimer = 0;}
    @Override public void invalidate() {if (hasValidMetaTileEntity()) {mMetaTileEntity.onRemoval(); mMetaTileEntity.inValidate(); mMetaTileEntity.mBaseMetaTileEntity = null;} if (mIsAddedToEnet) mIsAddedToEnet = !GT_ModHandler.removeTileFromEnet(this); super.invalidate();}
    @Override public boolean acceptsEnergyFrom(TileEntity aReceiver, Direction aDirection) {if (isInvalid()||mReleaseEnergy) return false; if (hasValidMetaTileEntity()) return mMetaTileEntity.isInputFacing((short)aDirection.toSideValue()); return false;}
    @Override public boolean emitsEnergyTo(TileEntity aReceiver, Direction aDirection) {if (isInvalid()||mReleaseEnergy) return mReleaseEnergy; if (hasValidMetaTileEntity()) return mMetaTileEntity.isOutputFacing((short)aDirection.toSideValue()); return false;}
    @Override public ItemStack getStackInSlotOnClosing(int slot) {ItemStack stack = getStackInSlot(slot); if (stack != null) setInventorySlotContents(slot, null); return stack;}
    @Override public ItemStack decrStackSize(int aIndex, int aAmount) {ItemStack stack = getStackInSlot(aIndex); if (stack != null) {if (stack.stackSize <= aAmount) {setInventorySlotContents(aIndex, null);} else {stack = stack.splitStack(aAmount); if (stack.stackSize == 0) {setInventorySlotContents(aIndex, null);}}} return stack;}
	@Override public int getMaxEnergyOutput() {if (mReleaseEnergy) return Integer.MAX_VALUE; if (hasValidMetaTileEntity()) return mMetaTileEntity.maxEUOutput(); return 0;}
	@Override public int demandsEnergy() {if (mReleaseEnergy || !hasValidMetaTileEntity()) return 0; return getCapacity() - mMetaTileEntity.getEnergyVar();}
	@Override public int injectEnergy(Direction directionFrom, int aAmount) {if (!hasValidMetaTileEntity()) return aAmount; if (aAmount > mMetaTileEntity.maxEUInput()) {doExplosion(aAmount); return 0;} setStoredEnergy(mMetaTileEntity.getEnergyVar() + aAmount); return 0;}
	@Override public int getCapacity() {if (hasValidMetaTileEntity()) return mMetaTileEntity.maxEUStore(); return 0;}
	@Override public int getOutput() {if (hasValidMetaTileEntity()) return mMetaTileEntity.maxEUOutput(); return 0;}
	@Override public void onMachineBlockUpdate() {if (hasValidMetaTileEntity()) mMetaTileEntity.onMachineBlockUpdate();}
	@Override public int fill(ForgeDirection from, LiquidStack resource, boolean doFill) {if (hasValidMetaTileEntity()) return mMetaTileEntity.fill(resource, doFill); return 0;}
	@Override public int fill(int tankIndex, LiquidStack resource, boolean doFill) {if (hasValidMetaTileEntity()) return mMetaTileEntity.fill(resource, doFill); return 0;}
	@Override public LiquidStack drain(ForgeDirection from, int maxDrain, boolean doDrain) {if (hasValidMetaTileEntity()) return mMetaTileEntity.drain(maxDrain, doDrain); return null;}
	@Override public LiquidStack drain(int tankIndex, int maxDrain, boolean doDrain) {if (hasValidMetaTileEntity()) return mMetaTileEntity.drain(maxDrain, doDrain); return null;}
	@Override public ILiquidTank[] getTanks(ForgeDirection direction) {if (hasValidMetaTileEntity() && mMetaTileEntity.getCapacity()>0) return new ILiquidTank[] {mMetaTileEntity}; return new ILiquidTank[] {};}
	@Override public ILiquidTank getTank(ForgeDirection direction, LiquidStack type) {if (hasValidMetaTileEntity() && (type == null || (type != null && type.isLiquidEqual(mMetaTileEntity.getLiquid())))) return mMetaTileEntity; return null;}
	@Override public ItemStack getWrenchDrop(EntityPlayer entityPlayer) {return new ItemStack(GT_Mod.instance.mBlocks[1], 1, mID);}
	@Override public void setStored(int aEU) {if (hasValidMetaTileEntity()) setStoredEnergy(aEU);}
	@Override public boolean isTeleporterCompatible(Direction side) {return false;}
	@Override public int getMaxSafeInput() {if (hasValidMetaTileEntity()) return mMetaTileEntity.maxEUInput(); return Integer.MAX_VALUE;}
	
	public boolean getRedstone() {return worldObj.isBlockIndirectlyGettingPowered(xCoord, yCoord, zCoord);}
	public boolean isActive() {return mActive;}
	public boolean isValidSlot(int aIndex) {if (hasValidMetaTileEntity()) return mMetaTileEntity.isValidSlot(aIndex); return false;}
    public boolean playerOwnsThis(EntityPlayer aPlayer) {if (!hasValidMetaTileEntity()) return false; if (mMetaTileEntity.ownerControl()) if (mOwnerName.equals("")&&!worldObj.isRemote) mOwnerName = aPlayer.username; else if (!aPlayer.username.equals("Player") && !mOwnerName.equals("Player") && !mOwnerName.equals(aPlayer.username)) return false; return true;}
    public boolean privateAccess() {if (!hasValidMetaTileEntity()) return false; return mMetaTileEntity.ownerControl();}
    public boolean unbreakable() {if (!hasValidMetaTileEntity()) return false; return mMetaTileEntity.unbreakable();}
    public boolean setStoredEnergy(int aEnergy) {if (!hasValidMetaTileEntity()) return false; if (aEnergy < 0) aEnergy = 0; mMetaTileEntity.setEnergyVar(aEnergy); return true;}
    public boolean increaseStoredEnergy(int aEnergy, boolean aIgnoreTooMuchEnergy) {if (!hasValidMetaTileEntity()) return false; if (mMetaTileEntity.getEnergyVar() < getCapacity() || aIgnoreTooMuchEnergy) {setStoredEnergy(mMetaTileEntity.getEnergyVar() + aEnergy); return true;} return false;}
	public boolean decreaseStoredEnergy(int aEnergy, boolean aIgnoreTooLessEnergy) {if (!hasValidMetaTileEntity()) return false; if (mMetaTileEntity.getEnergyVar() - aEnergy >= 0  || aIgnoreTooLessEnergy) {mMetaTileEntity.setEnergyVar(mMetaTileEntity.getEnergyVar() - aEnergy); if (mMetaTileEntity.getEnergyVar() < 0) {setStoredEnergy(0); return false;} return true;} return false;}
	public void doEnergyExplosion() {if (getCapacity() > 0 && getStored() >= getCapacity()/5) doExplosion(getOutput()*(getStored() >= getCapacity()?4:getStored() >= getCapacity()/2?2:1));}
	public int getTier(int aValue) {return aValue<=32?1:aValue<=128?2:aValue<=512?3:aValue<=2048?4:aValue<=8192?5:6;}
    public int getTexture(int aSide, int aMeta) {if (hasValidMetaTileEntity()) return mMetaTileEntity.getTextureIndex(aSide, mFacing); return 0;}
    public boolean hasValidMetaTileEntity() {return mMetaTileEntity != null && mMetaTileEntity.mBaseMetaTileEntity == this;}
    
    public void doExplosion(int aAmount) {
    	if (isAddedToEnergyNet() && GT_Mod.instance.mMachineWireFire) {
	        try {
	        	mReleaseEnergy = true;
	        	
	        	GT_ModHandler.removeTileFromEnet(this);
	        	GT_ModHandler.addTileToEnet(this);
	        	
	        	EnergyNet tEnergyNet = EnergyNet.getForWorld(worldObj);
	        	if (tEnergyNet != null) {
	        		tEnergyNet.emitEnergyFrom(this,   32);
	        		tEnergyNet.emitEnergyFrom(this,  128);
	        		tEnergyNet.emitEnergyFrom(this,  512);
	        		tEnergyNet.emitEnergyFrom(this, 2048);
	        		tEnergyNet.emitEnergyFrom(this, 8192);
	        	}
	        } catch(Exception e) {}
    	}
    	mReleaseEnergy = false;
    	if (hasValidMetaTileEntity()) mMetaTileEntity.onExplosion();
    	float tStrength = aAmount<10?1.0F:aAmount<32?2.0F:aAmount<128?3.0F:aAmount<512?4.0F:aAmount<2048?5.0F:aAmount<4096?6.0F:aAmount<8192?7.0F:8.0F;
    	int tX=xCoord, tY=yCoord, tZ=zCoord;
    	worldObj.setBlock(tX, tY, tZ, 0);
    	worldObj.createExplosion(null, tX+0.5, tY+0.5, tZ+0.5, tStrength, true);
    }
	
	@Override
	public int addEnergy(int aEnergy) {
		if (!hasValidMetaTileEntity()) return 0;
		if (aEnergy > 0)
			increaseStoredEnergy(aEnergy, true);
		else
			decreaseStoredEnergy(-aEnergy, true);
		return mMetaTileEntity.getEnergyVar();
	}
	
	@Override
	public void onNetworkUpdate(String field) {
		
	}
	
	@Override
	public List<String> getNetworkedFields() {
		ArrayList<String> rList = new ArrayList<String>();
		rList.add("mOwnerName");
		return rList;
	}
	
	public void onRightclick(EntityPlayer aPlayer) {
		mNeedsUpdate = true;
		try {
			if (aPlayer != null && hasValidMetaTileEntity() && mID > 15) mMetaTileEntity.onRightclick(aPlayer);
    	} catch(Throwable e) {
    		System.err.println("Encountered Exception while rightclicking TileEntity, the Game should've crashed now, but I prevented that. Please report immidietly to GregTech Intergalactical!!!");
    		e.printStackTrace();
    	}
	}
}
